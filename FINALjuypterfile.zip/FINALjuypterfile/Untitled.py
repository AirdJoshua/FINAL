#!/usr/bin/env python
# coding: utf-8

# In[247]:


import pandas as pd
from matplotlib import pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import numpy as np
import re
import requests, bs4
import seaborn as sns
from requests import get
from bs4 import BeautifulSoup
from time import sleep
from random import randint
from time import time
from sklearn.metrics import mean_squared_error
from math import sqrt
import tkinter as tk
from tkinter import *
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import (FigureCanvasTkAgg, 
NavigationToolbar2Tk)


# In[248]:


gfp = pd.read_csv('global_food_prices.csv')
rawcovid = pd.read_csv('time_series_covid19_deaths_global.csv')
GHI_2019 = pd.read_excel('2019GHI.xlsx' )
GHI_2020 = pd.read_excel('2020GHI.xlsx' )
GHI_2021 = pd.read_excel('2021GHI.xls' ) 


# In[249]:


GHI_2019.columns = ['Country','2019']
GHI_2020.columns = ['Country','2020']
GHI_2021.columns = ['Country','2021']


# In[250]:


exchange = pd.read_csv('joshy2.csv')
exchange = exchange.rename(columns={'Country Name': 'Country'})
exchange = exchange[['Country','2020']]
exchange = exchange.dropna()


# In[251]:


del gfp['adm1_name' ]
del gfp['mkt_id' ]
del gfp['mkt_name' ]
del gfp['cm_id' ]
del gfp['cur_id' ]
del gfp['pt_id' ]
del gfp['pt_name' ]
del gfp['mp_commoditysource' ]

del rawcovid['Province/State']
del rawcovid['Lat']
del rawcovid['Long']


# In[252]:


pred_gfp=gfp[gfp['mp_year'] >= 2019]


# In[253]:


del pred_gfp['adm1_id' ]
del pred_gfp['adm0_id' ]
del pred_gfp['um_id' ]
del pred_gfp['um_name' ]
del pred_gfp['cm_name' ]
del pred_gfp['cur_name']


# In[254]:


pred_gfp=pred_gfp.dropna()
pred_gfp = pred_gfp.rename(columns={'adm0_name': 'Country','mp_year':'Year','mp_month':'Month'})


# In[255]:


pred_gfp2 = pd.merge(pred_gfp, exchange, on='Country')
pred_gfp2['USD'] = pred_gfp2['mp_price'] * pred_gfp2['2020']
pred_gfp2 = pred_gfp2.drop(columns=['mp_price','2020'])
pred_gfp2


# In[256]:


pred_gfp2=(pred_gfp2.groupby(["Country","Month","Year"])['USD'].sum()).reset_index()


# In[257]:


GHI_Df = pd.merge(GHI_2019[GHI_2019.columns],
                 GHI_2020[GHI_2020.columns],
                 on=['Country'])


# In[258]:


GHI_Df = pd.merge(GHI_Df[GHI_Df.columns],
                 GHI_2021[GHI_2021.columns],
                 on=['Country'])


# In[259]:


GHI_Df['2019'] = GHI_Df['2019'].astype(str).str.replace('<', '').astype(float)
GHI_Df['2020'] = GHI_Df['2020'].astype(str).str.replace('<', '').astype(float)
GHI_Df['2021'] = GHI_Df['2021'].astype(str).str.replace('<', '').astype(float)


# In[260]:


ghi_df=GHI_Df
ghi_df.head(5)


# In[261]:


pred_ghi = ghi_df
pred_ghi = pd.melt(pred_ghi, id_vars=['Country'], var_name='Year')
pred_ghi['Year'] = pred_ghi['Year'].astype(float)
pred_ghi


# In[262]:


test69= pd.merge(pred_ghi[pred_ghi.columns],
                pred_gfp2[pred_gfp2.columns],
                 on=['Country','Year'] )


# In[223]:



def contry_Pred3(country):
    country = variable.get()
    global test69
    test=test69
    test=test[test["Country"]== country]
    test['Date']= pd.to_datetime(test[['Year', 'Month']].assign(DAY=1))
    test = test.drop(columns=['Year','Month'])
    test2 = test.groupby(["Date"])['USD','value'].sum()
    test2['Ratio'] = test2['value']/test2['USD']
    test2 = test2.drop(columns=['USD','value'])
    train3 = test2[test2.index.year < 2020]
    test3 = test2[test2.index.year > 2019]
    y_hat_avg = test3.copy()
    pred = []
    a = 0.3 #after testing multiple values for alpha, 0.4 seemed nearest to the alpha that produced the lowest value for RMS

    ft = pd.DataFrame.ewm(train3,alpha=a).mean()['Ratio'].iloc[-1]
    pred.append(ft)
    for i in range(1,len(test3['Ratio'])):
      dt=test3['Ratio'].iloc[i-1]
      ft_plus_1 = a*dt + (1-a)*ft;
      pred.append(ft_plus_1)
      ft = ft_plus_1
    y_hat_avg['SES'] = pd.Series(pred).values
    rms = sqrt(mean_squared_error(test3.Ratio, y_hat_avg.SES))
    
    fig=plt.figure(figsize=(16,8))
    plt.title('Forecasting of the Ratio of Global Hunger Index and Global Food Prices')
    plt.plot(train3['Ratio'], label='Train')
    plt.plot(test3['Ratio'], label='Test')
    plt.plot(y_hat_avg['SES'], label='SES')
    plt.legend(loc='best')
    plt.show()


# In[295]:


LARGEFONT =("Verdana", 15)
class tkinterApp(tk.Tk):
     
    # __init__ function for class tkinterApp
    def __init__(self, *args, **kwargs):
         
        # __init__ function for class Tk
        tk.Tk.__init__(self, *args, **kwargs)
         
        # creating a container
        container = tk.Frame(self) 
        container.pack(side = "top", fill = "both", expand = True)
  
        container.grid_rowconfigure(0, weight = 1)
        container.grid_columnconfigure(0, weight = 1)
  
        # initializing frames to an empty array
        self.frames = {} 
  
        # iterating through a tuple consisting
        # of the different page layouts
        for F in (StartPage, Page1, Page2):
  
            frame = F(container, self)
  
            # initializing frame of that object from
            # startpage, page1, page2 respectively with
            # for loop
            self.frames[F] = frame
  
            frame.grid(row = 0, column = 0, sticky ="nsew")
  
        self.show_frame(StartPage)
  
    # to display the current frame passed as
    # parameter
    def show_frame(self, cont):
        frame = self.frames[cont]
        frame.tkraise()
  


# In[296]:


class StartPage(tk.Frame):
    def contry_Pred3(country):
        country = variable.get()
        global test69
        test=test69
        test=test[test["Country"]== country]
        test['Date']= pd.to_datetime(test[['Year', 'Month']].assign(DAY=1))
        test = test.drop(columns=['Year','Month'])
        test2 = test.groupby(["Date"])['USD','value'].sum()
        test2['Ratio'] = test2['value']/test2['USD']
        test2 = test2.drop(columns=['USD','value'])
        train3 = test2[test2.index.year < 2020]
        test3 = test2[test2.index.year > 2019]
        y_hat_avg = test3.copy()
        pred = []
        a = 0.3 #after testing multiple values for alpha, 0.4 seemed nearest to the alpha that produced the lowest value for RMS

        ft = pd.DataFrame.ewm(train3,alpha=a).mean()['Ratio'].iloc[-1]
        pred.append(ft)
        for i in range(1,len(test3['Ratio'])):
          dt=test3['Ratio'].iloc[i-1]
          ft_plus_1 = a*dt + (1-a)*ft;
          pred.append(ft_plus_1)
          ft = ft_plus_1
        y_hat_avg['SES'] = pd.Series(pred).values
        rms = sqrt(mean_squared_error(test3.Ratio, y_hat_avg.SES))

        fig=plt.figure(figsize=(16,8))
        plt.title('Forecasting of the Ratio of Global Hunger Index and Global Food Prices')
        plt.plot(train3['Ratio'], label='Train')
        plt.plot(test3['Ratio'], label='Test')
        plt.plot(y_hat_avg['SES'], label='SES')
        plt.legend(loc='best')
        plt.show()
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
         
        # label of frame Layout 2
        label = ttk.Label(self, text ="How food prices would continue to affect each countries’ GHI relative change after the pandemic", font = LARGEFONT)
         
        # putting the grid in its place by using
        # grid
        label.grid(row = 0, column = 4, padx = 10, pady = 10)
  
        button1 = ttk.Button(self, text ="Global Food Price Prediction Analysis",
        command = lambda : controller.show_frame(Page1))
    
        countries= ['Belarus', 'Turkey', 'Argentina', 'Kazakhstan',
       'Russian Federation', 'Mexico', 'China', 'Colombia', 'Armenia',
       'Paraguay', 'Peru', 'Dominican Republic', 'Panama', 'El Salvador',
       'Mongolia', 'Thailand', 'Jordan', 'Ecuador', 'Lebanon', 'Honduras',
       'Nicaragua', 'Ghana', 'South Africa', 'Sri Lanka', 'Senegal',
       'Iraq', 'Myanmar', 'Indonesia', 'Philippines', 'Guatemala',
       'Nepal', 'Cameroon', 'Cambodia', 'Malawi', 'Lesotho', 'Togo',
       'Benin', 'Mali', 'Namibia', 'Kenya', 'Bangladesh', 'Burkina Faso',
       'Mauritania', 'Nigeria', 'Pakistan', 'Mozambique', 'Ethiopia',
       'Rwanda', 'Angola', 'Sierra Leone', 'Sudan', 'Afghanistan',
       'Haiti', 'Liberia', 'Madagascar', 'Chad',
       'Central African Republic']
        variable = StringVar()
        
            
        dropdown = OptionMenu(self,variable,*countries,command=contry_Pred3)
        dropdown.grid(row = 1, column = 3, padx = 10, pady = 10)
        # putting the button in its place by
        # using grid
        button1.grid(row = 1, column = 1, padx = 10, pady = 10)
  
        ## button to show frame 2 with text layout2
        button2 = ttk.Button(self, text ="Mortality Rate Prediction",
        command = lambda : controller.show_frame(Page2))
     
        # putting the button in its place by
        # using grid
        button2.grid(row = 2, column = 1, padx = 10, pady = 10)
  
          
  


# In[297]:


class Page1(tk.Frame):
     
    def __init__(self, parent, controller):
         
        tk.Frame.__init__(self, parent)
        label = ttk.Label(self, text ="Page 1", font = LARGEFONT)
        label.grid(row = 0, column = 4, padx = 10, pady = 10)
  
        # button to show frame 2 with text
        # layout2
        button1 = ttk.Button(self, text ="GHI Changes",
                            command = lambda : controller.show_frame(StartPage))
     
        # putting the button in its place
        # by using grid
        button1.grid(row = 1, column = 1, padx = 10, pady = 10)
  
        # button to show frame 2 with text
        # layout2
        button2 = ttk.Button(self, text ="Mortality Rate Prediction",
                            command = lambda : controller.show_frame(Page2))
     
        # putting the button in its place by
        # using grid
        button2.grid(row = 2, column = 1, padx = 10, pady = 10)
  
  
  


# In[298]:


class Page2(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)
        label = ttk.Label(self, text ="Page 2", font = LARGEFONT)
        label.grid(row = 0, column = 4, padx = 10, pady = 10)
  
        # button to show frame 2 with text
        # layout2
        button1 = ttk.Button(self, text ="Global Food Price Prediction Analysis",
                            command = lambda : controller.show_frame(Page1))
     
        # putting the button in its place by
        # using grid
        button1.grid(row = 1, column = 1, padx = 10, pady = 10)
  
        # button to show frame 3 with text
        # layout3
        button2 = ttk.Button(self, text ="GHI Changes ",
                            command = lambda : controller.show_frame(StartPage))
     
        # putting the button in its place by
        # using grid
        button2.grid(row = 2, column = 1, padx = 10, pady = 10)
  


# In[299]:


app = tkinterApp()
app.mainloop()


# In[ ]:





# In[ ]:




